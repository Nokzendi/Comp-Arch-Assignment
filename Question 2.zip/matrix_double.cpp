#include <bits/stdc++.h>
using namespace std;

void multiplier(vector<vector<double>> &m1, vector<vector<double>> &m2, vector<vector<double>> &m3, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            for (int k = 0; k < size; k++)
            {
                m3[i][j] += m1[i][k] * m2[k][j];
            }
        }
    }
}
void print(vector<vector<double>> &m, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            cout << m[i][j] << " ";
        }
        cout << '\n';
    }
}

void populate(vector<vector<double>> &m, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            m[i][j] = (double(rand()) / double((RAND_MAX)) * 200000);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int size = 32;
    // cin >> size;

    srand(time(0));

    vector<vector<double>> matrix1(size, vector<double>(size));
    vector<vector<double>> matrix2(size, vector<double>(size));
    vector<vector<double>> matrix3(size, vector<double>(size, 0));

    populate(matrix1, size);
    populate(matrix2, size);

    struct timespec start, end;

    timespec_get(&start, TIME_UTC);

    multiplier(matrix1, matrix2, matrix3, size);

    timespec_get(&end, TIME_UTC);

    double total_time;
    total_time = (end.tv_sec - start.tv_sec) * 1e9;
    total_time = (total_time + (end.tv_nsec - start.tv_nsec)) * 1e-9;
    cout << "Total time taken is : " << total_time << "s";
    // cout << "First Matrix is : " << '\n'
    //      << '\n';
    // print(matrix1, size);
    // cout << '\n';
    // cout << "Second Matrix is : " << '\n'
    //      << '\n';
    // print(matrix2, size);
    // cout << '\n';
    // cout << "Matrix product is : " << '\n'
    //      << '\n';
    // print(matrix3, size);

    return 0;
}