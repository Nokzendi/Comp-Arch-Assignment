import random
import timeit
size = 32


m1 = []
m2 = []
m3 = []

for i in range(size):
    a = []
    for j in range(size):
        a.append(random.uniform(-2147483648, 2147483647))
    m1.append(a)

for i in range(size):
    a = []
    for j in range(size):
        a.append(random.uniform(-2147483648, 2147483647))
    m2.append(a)

start = timeit.default_timer()

for i in range(size):
    a = []
    for j in range(size):
        value = 0
        for k in range(size):
            value += m1[i][k] * m2[k][j]

        a.append(value)
    m3.append(a)
stop = timeit.default_timer()


# for i in range(size):
#     for j in range(size-1):
#         print(m3[i][j], end=' ')
#     print(m3[i][size-1])

print("Time : ", stop-start)
