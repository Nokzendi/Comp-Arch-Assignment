#include <iostream>
#include <time.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    double long values[101];
    values[0] = 0;
    values[1] = 1;
    cout << values[0] << '\n';
    cout << values[1] << '\n';

    struct timespec start, end;

    timespec_get(&start, TIME_UTC);

    for (int i = 2; i <= 100; i++)
    {
        values[i] = values[i - 1] + values[i - 2];
        cout << i << ": " << values[i] << '\n';
    }

    timespec_get(&end, TIME_UTC);
    
    double total_time;
    total_time = (end.tv_sec - start.tv_sec) * 1e9;
    total_time = (total_time + (end.tv_nsec - start.tv_nsec)) * 1e-9;
    cout << "Total time taken is : " << total_time << "s";
    return 0;
}
