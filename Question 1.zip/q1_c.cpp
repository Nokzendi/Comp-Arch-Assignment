#include <bits/stdc++.h>
#include <time.h>
using namespace std;

double long terms[100]; // Creating an array to store the values of the function calls

double long fib(int n)
{
    if (n == 0 || n == 1)
    {
        return n;
    }

    if (terms[n] != 0)
    {
        return terms[n];
    }

    else
    {
        terms[n] = fib(n - 1) + fib(n - 2);
        return terms[n];
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n = 100;
    // cin >> n;

    struct timespec start, end;

    timespec_get(&start, TIME_UTC);

    for (int i = 0; i <= n; i++)
    {
        cout << i << " : " << fib(i) << '\n';
    }

    timespec_get(&end, TIME_UTC);
    
    double total_time;
    total_time = (end.tv_sec - start.tv_sec) * 1e9;
    total_time = (total_time + (end.tv_nsec - start.tv_nsec)) * 1e-9;
    cout << "Total time taken is : " << total_time << "s";
    return 0;
}