#include <bits/stdc++.h>
#include <time.h>
using namespace std;

double long fib(int n)
{
    if (n == 0 || n == 1)
    {
        return n;
    }
    else
    {
        return (fib(n - 1) + fib(n - 2));
    }
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    struct timespec start, end;
    int n = 60;
    // cin >> n;

    timespec_get(&start, TIME_UTC); // Starting to track the time

    for (int i = 0; i <= n; i++)
    {
        cout << i << ": " << fib(i) << endl;
    }

    timespec_get(&end, TIME_UTC); // Taking the end time of the algorithm

    // Calculating total time taken by the program in seconds
    double total_time;
    total_time = (end.tv_sec - start.tv_sec) * 1e9;
    total_time = (total_time + (end.tv_nsec - start.tv_nsec)) * 1e-9;
    cout << "Total time taken is : " << total_time << "s";
    return 0;
}