#include <bits/stdc++.h>
#include <time.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    double long n1 = 0, n2 = 1, n3;
    cout << "0: " << n1 << '\n';
    cout << "1: " << n2 << '\n';

    struct timespec start, end;

    timespec_get(&start, TIME_UTC);

    for (int i = 2; i <= 100; i++)
    {
        n3 = n1 + n2;
        cout << i << ": " << n3 << '\n';
        n1 = n2;
        n2 = n3;
    }

    timespec_get(&end, TIME_UTC);
    
    double total_time;
    total_time = (end.tv_sec - start.tv_sec) * 1e9;
    total_time = (total_time + (end.tv_nsec - start.tv_nsec)) * 1e-9;
    cout << "Total time taken is : " << total_time << "s";
    return 0;
}
